document.getElementById('submit-review').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Thank you for your review!');
});

document.getElementById('lead-form').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Thank you! We will contact you shortly.');
});